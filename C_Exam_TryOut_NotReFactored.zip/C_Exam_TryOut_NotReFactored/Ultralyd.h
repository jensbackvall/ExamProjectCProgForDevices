#ifndef ULTRA_LYD
#define ULTRA_LYD

int distance(int,int);

#endif